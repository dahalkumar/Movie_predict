# Importing the modules in the package
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Reading the input data into Pandas Dataframe from the CSV file.
csv_data = pd.read_csv('data_set.csv')
X = csv_data.iloc[:,0]
Y = csv_data.iloc[:,1]

x_array = X.to_numpy()
y_array = Y.to_numpy()
#x_array = np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30])
#y_array = np.array([12.30257,20.1944,53.47424,60.52269,61.85855,70.42899,86.55053,54.28762,69.02268,
#           100.4699,106.9244,115.7368,74.14187,126.5221,119.9432,139.9098,133.7649,152.9818,
#           157.5315,164.2307,130.2153,136.0519,160.7053,184.7324,152.8735,164.4765,169.6488,187.0767,174.1397,217.3314,
#           198.0507])

# Building the Model
# The main objective of the Gradient Descent model is to minimize the cost function/loss function/penality function for the best possible values of slope and intercept
# In Gradient Descent model we have to start the model with some initial values for slope and Y-intercept and train the model by increasing the v
# values of slope and intecept ,here m_curr --> slope and Y-intercept --> b_curr

m_curr = 0
b_curr= 0

# The rate at which the parameters are updated during the gradient descent process
rate_of_approach = 0.0001

# The iterations are the no of times we have to run the model with the varing parameters
iterations = 100

# In order to minimize the loss function, we have to differentiate the loss function w.r.t. m,b 
#𝜕𝐿𝑜𝑠𝑠/𝜕𝑚=0, 𝜕𝐿𝑜𝑠𝑠/𝜕𝑏=0
n = len(x_array)
#plt.scatter(x_array,y_array,color='red',marker='+',linewidth='5')
for ele in range(iterations):
    Y_pred = (m_curr * x_array) + b_curr
#Loss=(1/n)Σ(y-(mx+b))2
    loss_function = (1/n) * sum([ele**2 for ele in (y_array - Y_pred)])
#𝜕𝐿𝑜𝑠𝑠/𝜕𝑏=(−2Σ(𝑦−𝑚𝑥−𝑏))/𝑛=(−2Σ(𝑦−𝑦′))/𝑛)=0
    b_derv = -(2/n)*sum(y_array - Y_pred)
#𝜕𝐿𝑜𝑠𝑠/𝜕𝑚=(−2Σ(𝑦−𝑚𝑥−𝑏))/𝑛=(−2Σ𝑥(𝑦−𝑦′))/𝑛)=0
    m_derv = -(2/n)*sum(X*(y_array - Y_pred))
# The next slope and intercept can be caluclated by subtracting the m_curr,b_curr the rate_of_approach with derivate of loss function w.r.t. m and b
#mi+1 = mi - ((rate_of_approach)*𝜕𝐿𝑜𝑠𝑠/𝜕𝑚)
    m_curr = m_curr - (rate_of_approach)*m_derv
#bi+1 = bi - ((rate_of_approach)*𝜕𝐿𝑜𝑠𝑠/𝜕b)
    b_curr = b_curr - (rate_of_approach)*b_derv
    print("SLOPE - {}, Y-intercept- {}, Loss Function(COST): {}, COUNT_NUM: {}".format(m_curr,b_curr,loss_function,ele))

plt.title("The Graph with X,Y values - Scaterr and X,Y_pred in line")
plt.scatter(X, Y)
plt.xlabel("X-axis --> X values")
plt.ylabel("Y-axis --> Y_Pred values")
plt.plot(X,Y_pred,color='red')
plt.legend()
plt.show()


 





